classdef ElemObj
    properties
        D
        L
        Solution
        t {mustBeNumeric} = 0 % Current time for mesh
    end
    properties (Dependent)
        E % error
        L2 % L2 Norm error for the mesh
    end
    methods
        function obj = ElemObj() 
            obj.name = name; 
            obj.position = position; 
        end
        
    end
end